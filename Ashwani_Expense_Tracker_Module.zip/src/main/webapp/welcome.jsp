<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%
  Object userId = session.getAttribute("userId");
  if (userId == null) { response.sendRedirect("login.html"); return; }
  String userName = (String) session.getAttribute("userName");
  if (userName == null) userName = "User";
  userName = userName.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&#x27;");
%>
<!doctype html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Dashboard | Expense Tracker</title><link rel="stylesheet" href="style.css"></head>
<body><main class="card"><h1>Hello, <%= userName %>!</h1><p>Your login is working.</p><p>This is a temporary landing page. Your teammate's dashboard and expense modules can be connected here.</p><form action="logout" method="post"><button type="submit">Logout</button></form></main></body></html>
